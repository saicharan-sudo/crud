// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  serverURL: 'http://localhost:8090/',
  OTT_SERVER_DOMAIN: 'https://cloud-pp.verizon.com/',
  CLOUD_URL: 'vzCloud/home/cloudOverview.action',
  ENABLE_REGISTRATION: 'N',
  AM_LOGOUT_URL: 'https://securesit2.verizon.com/signin',
  AM_LOGIN_URL: 'https://securesit2.verizon.com/signin/user/logout',
  OBI_URL: 'https://jsl.qat.obi.aol.com/obipmservice',
  APP_STORE_URL: 'https://itunes.apple.com/us/app/verizon-cloud/id645682444?mt=8',
  PLAY_STORE_URL: 'https://play.google.com/store/apps/details?id=com.vcast.mediamanager'
};
