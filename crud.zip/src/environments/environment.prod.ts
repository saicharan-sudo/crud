export const environment = {
  production: true,
  serverURL: '/',
  OTT_SERVER_DOMAIN: 'https://secure.verizon.com/',
  CLOUD_URL: 'vzCloud/home/cloudOverview.action',
  ENABLE_REGISTRATION: 'N',
  AM_LOGOUT_URL: 'https://secure.verizon.com/signin',
  AM_LOGIN_URL: 'https://secure.verizon.com/signin/user/logout',
  OBI_URL: 'https://jsl.prod.obi.aol.com/obipmservice',
  APP_STORE_URL: 'https://itunes.apple.com/us/app/verizon-cloud/id645682444?mt=8',
  PLAY_STORE_URL: 'https://play.google.com/store/apps/details?id=com.vcast.mediamanager'
};
