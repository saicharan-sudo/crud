import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Plan } from './plan';
import { GlobalHttpService } from '../common/global-http.service';
import { DataService } from '../common/data.service';
import { CurrencyPipe } from '@angular/common';
import { PopupService } from '../common/popup-dialog/popup.service';
import { PopupModel } from '../common/popup-dialog/popup.model';
import { Callback } from '../common/popup-dialog/callback';

@Component({
    selector: 'app-plans',
    templateUrl: './plans.component.html',
    styleUrls: ['./plans.component.css']
})
export class PlansComponent implements OnInit {
    private planSelectionUrl = 'vzCloudOTT/planSelection';
    private listInstrumentUrl = 'vzCloudOTT/listInstruments';
    loginText: String = 'logout';
    url = 'vzCloudOTT/getView';
    planItems: Plan[];
    lookUpUrl = 'vzCloudOTT/userlookup';
    userAccountSummary: any;
    selectedPlan: Object;

    constructor(
        private globalHttpService: GlobalHttpService,
        private data: DataService,
        private router: Router,
        private popupService: PopupService
    ) { }

    ngOnInit() {
        this.userLookUp();
        this.getPlans();
    }

    onSelect(plan: Plan): void {
        this.selectedPlan = plan;
    }

    checkPlanAndRoute(): void {
        if (this.selectedPlan) {
            this.data.setPlanDetails({
                'availablePlan': this.planItems,
                'selectedPlan': this.selectedPlan
            });
            this.globalHttpService.makePostCall(this.planSelectionUrl, this.selectedPlan)
                .subscribe(response => {
                    if (response.statusCode !== '200') {
                        this.showUnableToProcced('We are unable to procced further at this time, please try again later.');
                    } else {
                        this.routeNext(response.additionalProperties.listInstrument);
                    }
                },
                error => {
                    this.showUnableToProcced('We are unable to procced further at this time, please try again later.');
                });
        }
    }

    routeNext(listInstruments: any): void {
        try {
            const paymentInfo: any = this.data.getPaymentInfo();
            if ( paymentInfo ) {
                const { userInfo, billingInfo, ccInfo } = paymentInfo;
                this.router.navigate(['/checkout']);
            } else {
                if ( listInstruments && listInstruments.result ) {
                    const listInstrument = listInstruments.result.instruments.instrument.filter(function(obj){
                        return obj.defaultFlag === true;
                    });
                    const billingInfo = listInstrument[0].userInformation.billingAddress;
                    const ccInfo = listInstrument[0].paymentInstrument;
                    const userInfo = listInstrument[0].userInformation.firstUserName;
                    this.data.setPaymentInfo({billingInfo, ccInfo, userInfo});
                    this.router.navigate(['/checkout']);
                } else {
                    this.router.navigate(['/payment']);
                }
            }
        } catch (error) {
            this.router.navigate(['/payment']);
        }
    }

    getPlans(): void {
        const planDetails: any = this.data.getPlanDetails();
        if (planDetails && planDetails.availablePlan) {
            this.planItems = planDetails.availablePlan;
            this.selectedPlan = planDetails.selectedPlan ? planDetails.selectedPlan : undefined;
        } else {
            this.globalHttpService.makePostCall(this.url, {})
                .subscribe(response => {
                    try {
                        if (response && response.RespGetView && response.RespGetView.View
                            && response.RespGetView.View.Category && response.RespGetView.View.Category.ChildGroup) {
                            const items = response.RespGetView.View.Category.ChildGroup.Item;
                            items.sort(function (a, b) {
                                return (a.PricePlanPackageDetails.NoOfLicenses - b.PricePlanPackageDetails.NoOfLicenses);
                            });
                            this.planItems = items.map(item => {
                                console.log(item.PricePlanPackageDetails.NoOfLicenses);
                                const planSpaceUnit = this.getPlanSpaceUnit(item.PricePlanPackageDetails.NoOfLicenses);


                                return {
                                    'featurePlanSize': planSpaceUnit.size,
                                    'isValid': true,
                                    'featurePlanUnit': planSpaceUnit.unit,
                                    'contentID': item.ContentID.trim(),
                                    'cartLineItemId': item.ItemID,
                                    'pricePlanPackageID': item.PricePlanPackage.PPPID,
                                    'pricePlanPackagePurchasePrice': item.PricePlanPackage.PurchasePrice
                                };
                            });
                            this.selectedPlan = this.planItems.filter(item => item.isValid)[0];
                            this.data.setPlanDetails({
                                'availablePlan': this.planItems
                            });
                        }
                    } catch (err) {
                        this.showUnableToProcced('We are unable to procced further at this time, please try again later.');
                    }
                }, error => {
                    this.showUnableToProcced('We are unable to procced further at this time, please try again later.');
                });
        }
    }

    userLookUp(): void {
        const userInfo: any = this.data.getUserInfo();
        if (userInfo && userInfo.accountSummary && userInfo.accountSummary.userStatus === 'Archived') {
            const attributes = userInfo.accountSummary.attributes;
            this.userAccountSummary = attributes.reduce(function (map, obj) {
                map[obj.name] = obj.value;
                return map;
            }, {});

            if (!this.checkPlanAvailability(this.userAccountSummary.desktopUsed)) {
                this.showUnableToProcced('We do not have a plan large enough for your content.');
            }
            const usedSpace = this.byteToSize(this.userAccountSummary.desktopUsed, 0);
            this.userAccountSummary.desktopUsed = usedSpace;
        }
    }

    checkPlanAvailability(usedSapce): Boolean {
        console.log(this);
        if (usedSapce > 1099511627776) {
            return false;
        }
        if (usedSapce > 644245094400) {
            const extraContent = usedSapce - 644245094400;
            this.userAccountSummary.extraContent = this.byteToSize(extraContent, 0);
            this.planItems = this.planItems.map(item => {
                item.isValid = (item.featurePlanSize !== 600);
                return item;
            });
            this.selectedPlan = this.planItems.filter(item => item.isValid)[0];
            this.data.setPlanDetails({
                'availablePlan': this.planItems
            });
        }
        return true;
    }

    showUnableToProcced(msg): void {
        let okCb: Callback;
        okCb = function (obj: any) {
            window.location.href = this.data.getProps('AM_LOGOUT_URL')
                + '?next=' + encodeURIComponent(this.data.getProps('OTT_SERVER_DOMAIN') + 'ott/');
        };
        this.popupService.show(<PopupModel>{
            title: 'Oops. Something went wrong.',
            message: msg,
            showOk: true,
            showCancel: false,
            showImage: true,
            showCross: false,
            bigDialog: false,
            isSuccess: false,
            okCallback: okCb.bind(this) });
    }

    byteToSize(bytes, decimalPoints): any {
        decimalPoints = decimalPoints || 2;
        bytes = parseInt(bytes, 10);
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes === 0) {
            return '0 Bytes';
        }
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        if (i === 0) {
            return bytes + ' ' + sizes[i];
        }
        return (bytes / Math.pow(1024, i)).toFixed(decimalPoints) + ' ' + sizes[i];
    }
    getPlanSpaceUnit(planSize): any {
        let size = planSize;

        let unit = 'GB';
        if (planSize >= 1000) {
            size = 1;
            unit = 'TB';
        }
        console.log(size);
        console.log(unit);
        return {
            'size': size,
            'unit': unit


        };
    }
}
