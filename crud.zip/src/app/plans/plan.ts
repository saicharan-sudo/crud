export class Plan {
    'featurePlanSize': number;
    'featurePlanUnit': string;
    'contentID': string;
    'cartLineItemId': number;
    'pricePlanPackageID': number;
    'pricePlanPackagePurchasePrice': string;
    'isValid' = true;
}
