import { TestBed, inject } from '@angular/core/testing';
import { AuthRouter } from './auth-router.service';
import { HttpClientModule, HttpClient, HttpHandler } from '@angular/common/http';
import { GlobalHttpService } from '../common/global-http.service';
import { LoaderService } from '../common/loader.service';
import { DataService } from '../common/data.service';

import {
    RouterTestingModule
} from '@angular/router/testing';
describe('AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthRouter, HttpClientModule, HttpClient,
        HttpHandler, GlobalHttpService, LoaderService,
        DataService
      ],
      imports: [ RouterTestingModule ]
    });
  });

  it('should be created', inject([AuthRouter], (service: AuthRouter) => {
    expect(service).toBeTruthy();
  }));
});
