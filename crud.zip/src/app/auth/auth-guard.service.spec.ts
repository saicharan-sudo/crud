import { TestBed, inject } from '@angular/core/testing';
import { AuthGuard } from './auth-guard.service';
import { HttpClientModule, HttpClient, HttpHandler } from '@angular/common/http';
import { GlobalHttpService } from '../common/global-http.service';
import { LoaderService } from '../common/loader.service';
import { DataService } from '../common/data.service';

import {
    RouterTestingModule
} from '@angular/router/testing';
describe('AuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthGuard, HttpClientModule, HttpClient,
        HttpHandler, GlobalHttpService, LoaderService,
        DataService
      ],
      imports: [ RouterTestingModule ]
    });
  });

  it('should be created', inject([AuthGuard], (service: AuthGuard) => {
    expect(service).toBeTruthy();
  }));
});
