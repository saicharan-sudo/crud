import { Injectable, Inject } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { GlobalHttpService } from '../common/global-http.service';
import { LoaderService } from '../common/loader.service';
import { DOCUMENT } from '@angular/platform-browser';
import { DataService } from '../common/data.service';

@Injectable()
export class AuthRouter implements CanActivate {

  private userDetail = 'vzCloudOTT/userlookup';
  constructor(
    private http: GlobalHttpService,
    private router: Router,
    private data: DataService,
    private loader: LoaderService,
    @Inject(DOCUMENT) private document
  ) { }
  getUserDetail(): Observable<any> {
    return this.http.makeGetCall(this.userDetail);
  }
  canActivate(): Observable<any> {
    return this.getUserDetail()
      .map(
        data => {
          if (data && data.ResponseInfo) {
            this.data.setUserInfo({
              responseInfo:  data.ResponseInfo,
              accountSummary: data.accountSummary
            });
            this.router.navigate(['/plans']);
          } else {
            this.data.setUserInfo({});
            this.router.navigate(['/login']);
          }
        }).
      catch(
        error => {
          const patt = new RegExp(/cloudOverview\.action/);
          this.loader.hide();
          if (error.status === 200 && error.url && patt.test(error.url)) {
            this.document.location.href = error.url;
          } else {
            this.router.navigate(['/login']);
          }
          return Observable.of(false);
        }
      );
  }
}