import { Injectable, Inject } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot,  RouterStateSnapshot} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { DOCUMENT } from '@angular/platform-browser';

import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { GlobalHttpService } from '../common/global-http.service';
import { environment } from '../../environments/environment';
import { LoaderService } from '../common/loader.service';
import { DataService } from '../common/data.service';

@Injectable()
export class AuthGuard implements CanActivate {

  private userLookUpUrl = 'vzCloudOTT/userlookup';
    constructor(
      private http: GlobalHttpService,
      private router: Router,
      private data: DataService,
      private loader: LoaderService,
      @Inject(DOCUMENT) private document
    ) { }
    getUserDetail(): Observable<any> {
        return this.http.makeGetCall(this.userLookUpUrl);
    }
  canActivate (): Observable<boolean> {
    const userInfo: any = this.data.getUserInfo();
    if ( userInfo && userInfo.responseInfo ) {
      if ( userInfo.accountSummary && userInfo.accountSummary.userStatus === 'Active' ) {
        this.document.location.href = this.data.getProps('OTT_SERVER_DOMAIN') + environment.CLOUD_URL;
      }
      return Observable.of(true);
    }
    return this.getUserDetail()
      .map(
        data => {
          this.data.setUserInfo({
            responseInfo:  data.ResponseInfo,
            accountSummary: data.accountSummary
          });
          if ( data.accountSummary && data.accountSummary.userStatus === 'Active' ) {
            this.document.location.href = this.data.getProps('OTT_SERVER_DOMAIN') + environment.CLOUD_URL;
          }
          return true;
        }).
      catch(
        error => {
          this.router.navigate(['/login']);
          return Observable.of(false);
        }
      );
  }
}
