import { Component, OnInit, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { GlobalHttpService } from '../common/global-http.service';
import { PopupService } from '../common/popup-dialog/popup.service';
import { PopupModel } from '../common/popup-dialog/popup.model';
import { Callback } from '../common/popup-dialog/callback';

import { environment } from '../../environments/environment';

import { DataService } from '../common/data.service';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
    private activateSubmitPurchaseCall = false;
    dataObj: object;
    loginText: String = 'logout';
    url = 'vzCloudOTT/checkoutcart';
    submitPurchaseUrl = 'vzCloudOTT/submitpurchase';
    logoutUrl = this.data.getProps('AM_LOGOUT_URL') + '?next=' + encodeURIComponent(this.data.getProps('OTT_SERVER_DOMAIN') + 'ott/');
    isValid = true;
    itemName: object;
    customerInfo: object;
    customerAddress: object;
    ccInfo: object;
    constructor(private globalHttpService: GlobalHttpService, private popupService: PopupService,
        private data: DataService, private router: Router, @Inject(DOCUMENT) private document) { }

    ngOnInit() {
        this.globalHttpService.makePostCall(this.url, {})
            .subscribe(response => {
                if ( response && response.responseCheckoutCartImpl
                    && response.responseCheckoutCartImpl.RespCheckoutCart.RespMsg.Code === '200' ) {
                    this.itemName = response.responseCheckoutCartImpl.RespCheckoutCart;
                    const customerInfos = response.listInstrumentResponse.result.instruments.instrument.filter(function(obj){
                        return obj.defaultFlag === true;
                    });
                    this.customerInfo = customerInfos[0].userInformation.firstUserName;
                    this.customerAddress = customerInfos[0].userInformation.billingAddress;
                    this.ccInfo = customerInfos[0].paymentInstrument;
                    this.data.setPaymentInfo({
                        userInfo: this.customerInfo,
                        billingInfo: this.customerAddress,
                        ccInfo: this.ccInfo
                    });
                    this.isValid = true;
                } else {
                    this.isValid = false;
                    const message = 'Please try again later';
                    let okCb: Callback;
                    okCb = function(){
                        this.document.location.href = this.logoutUrl;
                    };
                    this.showErrorPopUp(message, okCb.bind(this));
                }
            });
    }
      onSubmit() {
            this.isValid = false;
            if (!this.activateSubmitPurchaseCall) {
                this.activateSubmitPurchaseCall = true;
                this.globalHttpService.makePostCall(this.submitPurchaseUrl, {})
                .subscribe(response => {
                    const startTime: number = performance.now();
                    const endTime: number = performance.now();
                    if ((!response || !response.RespSubmitPurchase) && endTime - startTime > 10000 && endTime - startTime < 20000) {
                        this.popupService.show(<PopupModel>{
                            title: 'Thank you. Your order is being processed.',
                            message: '',
                            showOk: true,
                            okBtn: 'Continue',
                            showCancel: true,
                            showImage: true,
                            showCross: false,
                            bigDialog: false,
                            isSuccess: true
                            // okCallback: okCb.bind(this)
                        });
                    }else if (response && response.RespSubmitPurchase && response.RespSubmitPurchase.RespMsg.Code === '200') {
                        let navigatedUrl = this.data.getProps('OTT_SERVER_DOMAIN') + environment.CLOUD_URL + '?firstLogin=true';
                        let okBtnText = 'Continue to Cloud';
                        if (this.isiOS()) {
                            navigatedUrl = this.data.getProps('APP_STORE_URL');
                            okBtnText = 'Open App';
                        }else if (this.isAndroid()) {
                            navigatedUrl = this.data.getProps('PLAY_STORE_URL');
                            okBtnText = 'Open App';
                        }
                        let okCb: Callback;
                        okCb = function(url){
                            this.document.location.href = url;
                        };
                        this.popupService.show(<PopupModel>{
                            title: 'Thank you for joining Cloud.',
                            message: 'Begin backing up your content by logging into the Verizon Cloud mobile app',
                            showOk: true,
                            okBtn: okBtnText,
                            showCancel: false,
                            showImage: true,
                            showCross: false,
                            bigDialog: false,
                            isSuccess: true,
                            okCallback: okCb.bind(this, navigatedUrl)
                        });
                    } else {
                        this.activateSubmitPurchaseCall = false;
                        let okCb: Callback;
                        okCb = function(){
                            this.isValid = false;
                            if (response && response.RespSubmitPurchase && response.RespSubmitPurchase.RespMsg.Code === 'OBI302') {
                                this.router.navigate(['/payment']);
                            } else {
                                this.document.location.href = this.logoutUrl;
                            }
                        };
                        const message = response.RespSubmitPurchase ? response.RespSubmitPurchase.RespMsg.Desc : 'Please try again later';
                        this.showErrorPopUp(message, okCb.bind(this));
                     }
                });
            }
         }

    isAndroid() {
        return navigator.userAgent.match(/Android/i);
    }

    isiOS() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    }
    showErrorPopUp(message, cbFunction) {
        this.popupService.show(<PopupModel>{
                        title: 'Oops. Something went wrong.',
                        message: message,
                        showOk: true,
                        okBtn: 'Close',
                        showCancel: false,
                        showImage: true,
                        showCross: false,
                        bigDialog: false,
                        isSuccess: false,
                        okCallback: cbFunction
                    });
    }
}

