import { Component, OnInit, Input } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { DataService } from '../common/data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  private _name = 'login';
  @Input()
  set name(name: string) {
    this._name = (name && name.trim()) || 'login';
  }
  get name(): string { return this._name; }

  private logoutUrl: string = this.data.getProps('AM_LOGOUT_URL')
                            + '?next=' + encodeURIComponent(this.data.getProps('OTT_SERVER_DOMAIN') + 'ott/');
  url: SafeResourceUrl;
  constructor(private sanitizer: DomSanitizer, private data: DataService) {
      this.url = sanitizer.bypassSecurityTrustResourceUrl(this.logoutUrl);
   }

  ngOnInit() {
  }

}
