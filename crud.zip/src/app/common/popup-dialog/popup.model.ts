import { Callback } from './callback';

export interface PopupModel {
    title: string;
    message: string;
    imageURI: string;
    btnOk: string;
    btnCancel: string;
    showOk: boolean;
    showCancel: boolean;
    showImage: boolean;
    showCross: boolean;
    bigDialog: boolean;
    isSuccess: boolean;
    okBtn: string;
    okCallback ?: Callback;
    cancelCallback ?: Callback;
}
