import { Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import {PopupModel} from './popup.model';
import {PopupService} from './popup.service';
import { Callback } from './callback';
export interface ConfirmModel {
  title: string;
  message: string;
}

@Component({
  selector: 'app-popup-dialog',
  templateUrl: './popup-dialog.component.html',
  styleUrls: ['./popup-dialog.component.css']
})
export class PopupDialogComponent extends DialogComponent<PopupModel, boolean> implements ConfirmModel, OnInit {
  title: string;
  message: string;
  popupObj: PopupModel;
  show = false;
  okCallback: Callback;
  imageSrc= '/vzCloudOTT/ott/assets/images/cloud_sync.svg';
  @ViewChild('popupMessage') popupMessage: ElementRef;
  constructor(dialogService: DialogService, private popupService: PopupService, private elementRef: ElementRef) {
    super(dialogService);
  }
  confirm() {
    // we set dialog result as true on click on confirm button,
    // then we can get dialog result from caller codes
    this.result = true;
    this.show = false;
    if (this.okCallback) {
        this.okCallback();
    }
    // this.close();
  }
   close() {
    this.result = false;
    this.show = false;
    // this.close();
    }

 ngOnInit() {
     const self = this;
     this.popupService.popupState
        .subscribe((popUpObj: any) => {
            this.show = popUpObj.show;
         if (popUpObj.popUp) {
             this.popupObj = popUpObj.popUp;
             this.okCallback = this.popupObj.okCallback;
             this.imageSrc = this.popupObj.isSuccess ? 'assets/images/success.svg' : 'assets/images/failure.svg';
             setTimeout(() => {
                  this.elementRef.nativeElement.querySelector('.modal-body').innerHTML = this.popupObj.message;
             }, 0);

         }
        });
 }
}
