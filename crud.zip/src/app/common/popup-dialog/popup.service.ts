import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { PopupModel } from './popup.model';
@Injectable()
export class PopupService {
  private popupSubject = new Subject<any>();
  popupState = <any>this.popupSubject.asObservable();
  constructor() {}

  show(popupObj: PopupModel) {
    popupObj.okBtn = popupObj.okBtn || 'OK';
    this.popupSubject.next(<any>{show: true, popUp : popupObj});
    // this.popupSubject.next();
  }

  hide() {
    this.popupSubject.next(<any>{show: false});
  }

}

