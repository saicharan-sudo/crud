export type Callback = (obj ?: any)  => void;
