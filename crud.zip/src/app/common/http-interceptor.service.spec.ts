import { TestBed, inject } from '@angular/core/testing';

import { HttpInterceptorService } from './http-interceptor.service';
import { LoaderService } from './loader.service';
import { HttpClientModule, HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';
import { PopupService } from './popup-dialog/popup.service';
describe('HttpInterceptorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
          HttpInterceptorService, LoaderService, HttpClientModule,
          HttpClient, HttpHandler, PopupService
      ]
    });
  });

  it('should be created', inject([HttpInterceptorService], (service: HttpInterceptorService) => {
    expect(service).toBeTruthy();
  }));
});
