import { TestBed, inject } from '@angular/core/testing';

import { GlobalHttpService } from './global-http.service';
import { HttpClientModule, HttpClient, HttpHandler } from '@angular/common/http';
describe('GlobalHttpService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GlobalHttpService, HttpClientModule, HttpClient, HttpHandler],

    });
  });

  it('should be created', inject([GlobalHttpService], (service: GlobalHttpService) => {
    expect(service).toBeTruthy();
  }));
});
