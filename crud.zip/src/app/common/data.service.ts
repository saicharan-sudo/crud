import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
class Props {
  AM_LOGIN_URL: string;
  AM_LOGOUT_URL: string;
  APP_STORE_URL: string;
  OTT_SERVER_DOMAIN: string;
  ENABLE_REGISTRATION: string;
  OBI_URL: string;
  PLAY_STORE_URL: string;
}

@Injectable()
export class DataService {
  private paymentInfo: object;
  private planInfo: object;
  private userInfo: object;
  private props: Props;
  constructor() { }

  setPaymentInfo(obj: object) {
    this.paymentInfo = obj;
  }
  getPaymentInfo(): object {
    return this.paymentInfo;
  }
  setPlanDetails(obj: any) {
    this.planInfo = obj;
  }
  getPlanDetails(): object {
    return this.planInfo;
  }
  setUserInfo( obj: object ) {
    this.userInfo = obj;
  }
  getUserInfo(): object {
    return this.userInfo;
  }
  setProps( obj: Props ) {
    this.props = obj;
  }
  getProps( key: string ) {
    if (this.props) {
      return this.props[key];
    } else {
      return environment[key];
    }
  }
}
