import { Injectable } from '@angular/core';
import { Plan } from '../plans/plan';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const httpOptions = {
    headers : new HttpHeaders({
        'Content-Type' : 'application/json',
        // 'am_uuid' : '51954120-1e82-4b14-84c4-12bb35666810',
        // 'am_lob' : 'OTT'
        // 'am_uuid' : 'CloudOTTTest3'
    })
};

@Injectable()
export class GlobalHttpService {
    private baseUrl: string = environment.serverURL;
  constructor(private http: HttpClient) { }

  makeGetCall(url: string): Observable<any> {
    return this.http.get(this.baseUrl + url, httpOptions);
  }

  makePostCall(url: string, pramsObj: Object): Observable<any> {
        pramsObj = {'RequestParams' : pramsObj};
        return this.http.post(this.baseUrl + url, pramsObj, httpOptions)
        .pipe(
            catchError(this.handleError(url, []))
        );
  }

  private handleError<T> (operation = 'operation', result ?: T) {
    return ( error: any ): Observable<T> => {
        // Send error to remote logging
        console.log(error); // print to console

        // Return empty result
        return of(result as T);
    };
  }

}
