import { Component, OnInit, OnDestroy } from '@angular/core';
import { LoaderService } from '../loader.service';
import { LoaderState } from '../interfaces/loader';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-content-loader',
  templateUrl: './content-loader.component.html',
  styleUrls: ['./content-loader.component.css']
})
export class ContentLoaderComponent implements OnInit, OnDestroy {

  show = false;
  private subscription: Subscription;
  constructor(private loaderService: LoaderService) { }

  ngOnInit() {
      this.subscription = this.loaderService.loaderState
        .subscribe((state: LoaderState) => {
            this.show = state.show;
        });
  }

  ngOnDestroy() {
      this.subscription.unsubscribe();
  }

}
