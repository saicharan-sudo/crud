import { Injectable } from '@angular/core';
import {
        HttpRequest,
        HttpHandler,
        HttpEvent,
        HttpInterceptor,
        HttpResponse,
        HttpErrorResponse
    } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import { LoaderService } from './loader.service';
import {PopupService} from './popup-dialog/popup.service';
import {PopupModel} from './popup-dialog/popup.model';

@Injectable()
export class HttpInterceptorService implements HttpInterceptor {

  constructor(
                private loaderService: LoaderService,
                private popupService: PopupService
            ) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.showLoader(request);
    // request = request.clone({});
    return next.handle(request)
        .do((event: HttpEvent<any>) => {
            if ((event instanceof HttpResponse)) {
                this.hideLoader(request);
            }
        }, (err: any) => {
            this.hideLoader(request);
            if (err instanceof HttpErrorResponse) {
                console.log(err.status, err);
                if (err.status === 0 || err.status === 500) {
                  if (!request.url.includes('userlookup')) {
                    this.popupService.show(<PopupModel>{
                        title : 'Network Error',
                        message : 'We are unable to access your cloud right now, please try again later.',
                        showOk : true,
                        showCancel : false,
                        showImage : true,
                        showCross : false,
                        bigDialog : false,
                        isSuccess: false
                    });
                  }
                }
            }
        });
  }

  private showLoader(request: HttpRequest<any>): void {
    if (request && request.method.toLowerCase() !== 'options') {
        this.loaderService.show();
    }
  }

  private hideLoader(request: HttpRequest<any>): void {
    if (request && request.method.toLowerCase() !== 'options') {
        this.loaderService.hide();
    }
  }

}
