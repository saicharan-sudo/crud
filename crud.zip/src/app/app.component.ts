import { Component, OnInit } from '@angular/core';
import { GlobalHttpService } from './common/global-http.service';
import { DataService } from './common/data.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    showContainer = false;
    private getPropsUrl = 'vzCloudOTT/getProp';
    constructor(private globalHttpService: GlobalHttpService, private data: DataService) { }

    getProps(): any {
        const result = this.globalHttpService.makeGetCall(this.getPropsUrl)
        .subscribe(response => {
            if (response && response.properties) {
                const props = {
                    'OTT_SERVER_DOMAIN': response.properties.CLOUD_OTT_STATIC_URL,
                    'AM_LOGIN_URL': response.properties.AM_LOGIN_URL,
                    'AM_LOGOUT_URL': response.properties.AM_LOGOUT_URL,
                    'APP_STORE_URL': response.properties.APP_STORE,
                    'PLAY_STORE_URL': response.properties.PLAY_STORE,
                    'OBI_URL': response.properties.OBI_URL,
                    'ENABLE_REGISTRATION': response.properties.ENABLE_REGISTRATION,
                };
                this.data.setProps(props);
                const node = document.createElement('script');
                node.src = response.properties.OBI_URL + '/obick.umd.js';
                node.type = 'text/javascript';
                document.getElementsByTagName('head')[0].appendChild(node);
                this.showContainer = true;
            }
        });
    }

    ngOnInit() {
        this.getProps();
    }
}
