import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { BootstrapModalModule } from 'ng2-bootstrap-modal';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { PlansComponent } from './plans/plans.component';
import { PaymentComponent } from './payment/payment.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { AppRouterModule } from './/app-router.module';
import { DataService } from './common/data.service';
import { AuthGuard } from './auth/auth-guard.service';
import { AuthRouter } from './auth/auth-router.service';
import { GlobalHttpService } from './common/global-http.service';
import { PopupDialogComponent } from './common/popup-dialog/popup-dialog.component';
import { PopupService } from './common/popup-dialog/popup.service';
import { HttpInterceptorService } from './common/http-interceptor.service';
import { ContentLoaderComponent } from './common/content-loader/content-loader.component';
import { LoaderService } from './common/loader.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    PlansComponent,
    PaymentComponent,
    CheckoutComponent,
    PopupDialogComponent,
    ContentLoaderComponent
  ],
  imports: [
    BrowserModule,
    ButtonsModule.forRoot(),
    BootstrapModalModule.forRoot({container: document.body}),
    FormsModule,
    AppRouterModule,
    HttpClientModule
  ],
  providers: [
    DataService,
    AuthGuard,
    AuthRouter,
    GlobalHttpService,
    CookieService,
    {
        provide : HTTP_INTERCEPTORS,
        useClass : HttpInterceptorService,
        multi : true
    },
    LoaderService,
    PopupService
    ],
    entryComponents: [
        PopupDialogComponent
      ],
  bootstrap: [AppComponent]
})
export class AppModule { }
