import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { GlobalHttpService } from '../common/global-http.service';
import { DataService } from '../common/data.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    loginIframeUrl = '';
    url: SafeResourceUrl;
    private getPropsUrl = 'vzCloudOTT/getProp';
    constructor(private sanitizer: DomSanitizer, private globalHttpService: GlobalHttpService, private data: DataService) { }
    ngOnInit() {
      if (this.data.getProps('AM_LOGIN_URL')) {
        this.loginIframeUrl = this.data.getProps('AM_LOGIN_URL')
        + '?realm=vzw&hideRegistration=' + this.data.getProps('ENABLE_REGISTRATION')
        + '&clientId=ottw&customerType=CL&mode=i&userNameOnly=false&goto='
        + encodeURIComponent('https://cloud-pp.verizon.com/vzCloudOTT/validateuser');
      this.url = this.sanitizer.bypassSecurityTrustResourceUrl(this.loginIframeUrl);
      } else {
      this.globalHttpService.makeGetCall(this.getPropsUrl)
      .subscribe(response => {
          if (response && response.properties) {
              const props = {
                'OTT_SERVER_DOMAIN': response.properties.CLOUD_OTT_STATIC_URL,
                'AM_LOGIN_URL': response.properties.AM_LOGIN_URL,
                'AM_LOGOUT_URL': response.properties.AM_LOGOUT_URL,
                'APP_STORE_URL': response.properties.APP_STORE,
                'PLAY_STORE_URL': response.properties.PLAY_STORE,
                'OBI_URL': response.properties.OBI_URL,
                'ENABLE_REGISTRATION': response.properties.ENABLE_REGISTRATION,
              };
              this.data.setProps(props);
          }
          this.loginIframeUrl = this.data.getProps('AM_LOGIN_URL')
            + '?realm=vzw&hideRegistration=' + this.data.getProps('ENABLE_REGISTRATION')
            + '&clientId=ottw&customerType=CL&mode=i&userNameOnly=false&goto='
            + encodeURIComponent('https://cloud-pp.verizon.com/vzCloudOTT/validateuser');
          this.url = this.sanitizer.bypassSecurityTrustResourceUrl(this.loginIframeUrl);
        });
      }
    }
}
