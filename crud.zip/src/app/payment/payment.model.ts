export class PaymentModel {
    firstName: string;
    lastName: string;
    street1: string;
    city: string;
    zip: string;
    country = 'US';
    state: string;
    accountNumber = '';
    expiryMonth: string;
    expiryYear: string;
}
