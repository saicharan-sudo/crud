import { Component, OnInit, Renderer2, Inject, ChangeDetectorRef, AfterViewChecked, ViewChild, ElementRef } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { PaymentModel } from './payment.model';
import { GlobalHttpService } from '../common/global-http.service';
import {PopupService} from '../common/popup-dialog/popup.service';
import {PopupModel} from '../common/popup-dialog/popup.model';
import { Callback } from '../common/popup-dialog/callback';
import { DataService } from '../common/data.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit, AfterViewChecked {
  months: any[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  // years:Number[] = [2018,2019,2020,2021,2022,2023,2024,2025];
    years: Number[] = [];
   states: string[] = [
        'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
        'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
        'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
        'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
        'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'
    ];
  paymentModel: PaymentModel = new PaymentModel();
  loginText: String = 'logout';
  private url = 'vzCloudOTT/createInstrument';
  private listInstrumentUrl = 'vzCloudOTT/listInstruments';
  private reloadCheck = false;
  private response: Object; // will make generic HttpResponse model class later
  enableNext: boolean; // this flag is being used to enable/disable next button
  termsChecked: boolean;
  private obiServer: string =  this.data.getProps('OBI_URL');
  private OTT_SERVER_DOMAIN: string =  this.data.getProps('OTT_SERVER_DOMAIN');
  
  constructor(
        private ref: ChangeDetectorRef,
        private _renderer2: Renderer2,
        @Inject(DOCUMENT) private _document,
        private httpService: GlobalHttpService,
        private router: Router,
        private data: DataService,
        private popupService: PopupService) {
  }

  ngOnInit() {
      this.checkExistingUser();
      this.onLoad();
  }
  checkExistingUser() {
    const paymentInfo: any = this.data.getPaymentInfo();
    if ( paymentInfo ) {
        const { userInfo, billingInfo, ccInfo } = paymentInfo;
        this.setPaymentModel(billingInfo, userInfo, ccInfo);
    } else {
        this.httpService.makePostCall(this.listInstrumentUrl, {}).subscribe(response => {
            if ( response.statusCode === '200' && response.result.instruments ) {
                const listInstrument = response.result.instruments.instrument.filter(function(obj){
                    return obj.defaultFlag === true;
                });
                const billingInfo = listInstrument[0].userInformation.billingAddress;
                const ccInfo = listInstrument[0].paymentInstrument;
                const userInfo = listInstrument[0].userInformation.firstUserName;
                this.setPaymentModel(billingInfo, userInfo, ccInfo);
                this.data.setPaymentInfo({billingInfo, ccInfo, userInfo});
            }
        });
    }
  }

  setPaymentModel(billingInfo, userInfo, ccInfo) {
    this.paymentModel.firstName = userInfo.firstName;
    this.paymentModel.lastName = userInfo.lastName;
    this.paymentModel.street1 = billingInfo.street1;
    this.paymentModel.city = billingInfo.city;
    this.paymentModel.state = billingInfo.state;
    this.paymentModel.zip = billingInfo.zip;
    const expiryTimeStamp = parseInt(ccInfo.expiryDate, 10);
    if (expiryTimeStamp > Date.now()) {
        this.paymentModel.expiryMonth = ('0' + new Date(expiryTimeStamp).getMonth() + 1).slice(-2).toString();
        this.paymentModel.expiryYear = '' + new Date(expiryTimeStamp).getFullYear().toString();
    }
  }
  @ViewChild('card-number') iframeRef: ElementRef;
  onIframeLoad() {
    const iframe = this.iframeRef.nativeElement;
    const doc = iframe.contentDocument || iframe.contentWindow.document;
    const link = doc.createElement('link');
    link.rel = 'stylesheet';
    link.href = `"${this.OTT_SERVER_DOMAIN}/ott/assets/example.css"`; // Replace with the actual path to your CSS file
    doc.head.appendChild(link);
  }
  onLoad() {
    this.enableNext = true;
    this.termsChecked = false;
    // tslint:disable-next-line:no-eval
    const win = eval('window');
    if (!win.obick) {
        if (this.reloadCheck) {
            const okCB = function(){
                const amLogOutUrl = this.data.getProps('AM_LOGOUT_URL');
                const logoutUrl = amLogOutUrl + '?next=' + encodeURIComponent(this.data.getProps('OTT_SERVER_DOMAIN') + 'ott/');
                this._document.location.href = logoutUrl;
            };
            const msg = 'Please try again later.';
            this.errorPopUp(msg, okCB);
        } else {
            this.reloadCheck = true;
            setTimeout(() => { this.onLoad(); }, 500);
        }
        return;
    }
    const s = this._renderer2.createElement('script');
        s.type = `text/javascript`;
        s.text = `
            window.cardInput = obick(
        {
            serverUrl: "${this.obiServer}" // Development only
        })
        .then(
            function (checkout) {
                return checkout.input({
                    //onSubmit: startCheckout,
                    theme: {
                        iframe: {
                           style: "${this.OTT_SERVER_DOMAIN}ott/assets/example.css",
                            cardNumber: {
                                style: function(field) {
                                    return {
                                        "::disabled": field.input.status().generatingToken,
                                        "border": "10px solid red"
                                    };
                                }
                            },
                            cvv: {
                                style: function(field) {
                                    return {
                                        "::disabled": field.input.status().generatingToken,
                                   };
                                }
                            }
                        }
                    }
                }).then(
                    //${this.onIframeLoad()};
                    function (input) {
                        return input;
                    },
                    function (error) {
                        //window.console && window.console.error("Failed to create input", error);
                    });
            },
            function (error) {
                window.console && window.console.error("Failed to initialize checkout", error);
            });

        `;

        this._renderer2.appendChild(this._document.body, s);
        this.setExpiryYear(0);
        this.setExpiryMonth(0);
  }
    ngAfterViewChecked() {
        const x = document.getElementsByTagName('iframe');
        let runOnce = true;
        if (x.length > 0 && runOnce) {
            for (let i = 0; i < x.length; i++) {
                if (document.activeElement === x[i]) {
                    this._renderer2.selectRootElement('.checkbox-custom').checked = false;
                    this.enableNext = false;
                    this.termsChecked = false;
                    runOnce = false;
                    this.ref.detectChanges();
                }
            }
       }
    }

    setExpiryYear(selectedMonth: any): any {
        this.years = [];
        let currentYear =  new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1;
        if (parseInt(selectedMonth, 10) && parseInt(selectedMonth, 10) < currentMonth) {
            currentYear++;
        }
        for (let i = 0; i < 10; i++) {
            this.years.push(currentYear + i);
        }
    }
    errorPopUp(msg: String, callback: Function): any {
        this.popupService.show(
            <PopupModel>{
                title: ' Oops. Something went wrong.',
                message: msg,
                showOk: true,
                showCancel: false,
                showImage: true,
                showCross: false,
                bigDialog: false,
                isSuccess: false,
                okCallback: callback.bind(this)
            }
        );
    }
  onSubmit() {
            this.httpService.makePostCall(this.url, this.paymentModel)
            .subscribe(response => {
                this.response = response;
                this.paymentModel.accountNumber = '';
                if (response.statusCode === '200') {
                    this.router.navigate(['/checkout']);
                } else {
                    this.enableNext = false;
                    this._renderer2.selectRootElement('.checkbox-custom').checked = false;
                    let okCb: Callback;
                    okCb = function(){
                        console.log(response);
                        window.location.reload();
                    };
                    const msg = 'Error occurred. please verify your payment details.';
                    this.errorPopUp(msg, okCb);
                }
            });
       // this.popupService.show(<PopupModel>{title:'Payment Component Title',message:'Payment Component Message'});
    }

    confirmCheckout(e): void {
        const that = this;
         window['cardInput']
                .then(function (input) {
                    return input.createToken().then(
                        function (token) {
                            that.paymentModel.accountNumber = token;
                            if (e.srcElement.checked) {
                                that.enableNext = true;  that.termsChecked = true;
                            } else {
                                that.enableNext = false;  that.termsChecked = false;
                            }
                         },
                        function (error) {
                            let okCb: Callback;
                            okCb = function(){
                                console.log(error);
                            };
                            const msg = 'Error occurred. please verify your payment details.';
                            that.errorPopUp(msg, okCb);
                            e.srcElement.checked = false;
                            that.enableNext = false;
                            that.termsChecked = false;
                        });
                });
    }

    onKey(param: string): void {
        if (param) {
            this.enableNext = true;
        }
    }

    setExpiryMonth(selectedYear: any): void {
        this.months = [];
        const currentYear =  new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1;
        if (parseInt(selectedYear, 10) === currentYear) {
            for (let i = currentMonth; i <= 12; i++) {
               this.months.push(i);
            }
        } else {
            this.months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
        }
    }
}
