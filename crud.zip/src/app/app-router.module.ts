import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { PlansComponent } from './plans/plans.component';
import { PaymentComponent } from './payment/payment.component';
import { CheckoutComponent } from './checkout/checkout.component';

import { AuthGuard } from './auth/auth-guard.service';
import { AuthRouter } from './auth/auth-router.service';


const routes: Routes = [
  { path: '', canActivate: [AuthRouter], component: AppComponent },
  { path: 'login', component: LoginComponent },
  { path: 'header', component: HeaderComponent },
  { path: 'plans', canActivate: [AuthGuard], component: PlansComponent },
  { path: 'payment', canActivate: [AuthGuard], component: PaymentComponent },
  { path: 'checkout', canActivate: [AuthGuard], component: CheckoutComponent },
];

@NgModule({
  imports: [ RouterModule.forRoot(routes, {enableTracing: false, useHash: true}) ],
  exports: [ RouterModule ]
})

export class AppRouterModule {}
