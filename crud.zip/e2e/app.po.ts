import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/');
  }
*.classpath
*.project
*.settings/
target/
ott_installation/

  getParagraphText() {
    return element(by.css('app-root h1')).getText();
  }
}
