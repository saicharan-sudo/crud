package com.vzw.cloud.ott.security.filter;

import com.vzw.cloud.common.constants.CloudConstants;
import com.vzw.cloud.ott.util.AMConstants;
import com.vzw.cloud.ott.util.LogConstants;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.UUID;

public class LoggingFilter implements Filter {

    private static final Logger logger = LogManager.getLogger(LoggingFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpSession session = request.getSession(false);
        String am_uuid = request.getHeader(AMConstants.AM_UUID);
        String amLoginId = request.getHeader(AMConstants.AM_LOGIN_ID);
        String role = request.getHeader(AMConstants.AM_ROLE);
        String sessionId = session != null ? session.getId() : "";
        String clientIP = null;
        logger.info(LogConstants.LOGGED_IN_USER + amLoginId);
        logger.info(LogConstants.LOGGED_IN_USER_GUID + am_uuid);

        String ipAddress = "";
        if ( request.getHeader(CloudConstants.CLIENT_IPADDRESS_HEADER) != null ) {
            ipAddress = request.getHeader(CloudConstants.CLIENT_IPADDRESS_HEADER) + CloudConstants.COLON + role;
        } else {
            ipAddress = "NOT REAL CLIENT IP:" + request.getRemoteAddr() + CloudConstants.COLON + role;
        }
        
        ThreadContext.put("serverName", System.getProperty("serverName"));

        ThreadContext.put("Session", sessionId);
        if ( null == am_uuid ) {
            am_uuid = "Unknown";
        }
        ThreadContext.put("RemoteIP", ipAddress);
        String requestId = UUID.randomUUID().toString();
        ThreadContext.put("Account", am_uuid + CloudConstants.COLON + amLoginId);
        ThreadContext.put("Request", "Request" + " : " + requestId);
       
        
        logger.debug("serverName for OTT: " + System.getProperty("serverName"));
        logger.debug("Session Id is		::::::: " + sessionId);
        logger.debug("Account Number    ::::::: " + am_uuid);
        logger.debug("Mobile Number     ::::::: " + amLoginId);
        logger.debug("Request Id        ::::::: " + requestId);

        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }
}
