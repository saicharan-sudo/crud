package com.vzw.cloud.ott.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * StaticResourceConfiguration is a Spring Boot configuration to define the static folder and files for Cloud OTT.
 *
 * @author Madhusudhanan Krishnan(krisma3)
 */
@Configuration
public class StaticResourceConfiguration extends WebMvcConfigurerAdapter {

    private static final String[] CLASSPATH_RESOURCE_LOCATIONS = {
            "classpath:/META-INF/resources/", "classpath:/resources/",
            "classpath:/static/", "classpath:/META-INF/resources/ott/" };
    private static final String URL_PATH = "/ott/";
    private static final String FORWARD_OTT_INDEX_HTML = "forward:/ott/index.html";
    private static final String URL_PATTERN = "/**";

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(URL_PATTERN)
            .addResourceLocations(CLASSPATH_RESOURCE_LOCATIONS);
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController(URL_PATH).setViewName(FORWARD_OTT_INDEX_HTML);
    }
}