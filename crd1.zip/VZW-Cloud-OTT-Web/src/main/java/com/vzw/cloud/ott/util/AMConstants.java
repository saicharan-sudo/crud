package com.vzw.cloud.ott.util;

public class AMConstants {
    public static final String AM_UUID = "am_uuid";
    public static final String AM_LOB = "am_lob";
    public static final String AM_ACCOUNT_NUMBER = "am_account_number";
    public static final String AM_MOBILE_NUMBER = "am_mobile_number";
    public static final String MDN = "mdn";
    public static final String AM_ROLE = "am_role";
    public static final String AM_LOGIN_ID = "am_login_id";
    public static final String AM_PROD_NAME = "am_prod_name";
    public static final String AM_CSR_USER_NAME = "am_csr_user_name";
    public static final String AM_NAME = "am_name";
    public static final String AM_EMAIL_ADDRESS = "AM_EMAIL_ADDRESS";
    public static final String AM_CSR_ROLE = "am_csr_role";
}
