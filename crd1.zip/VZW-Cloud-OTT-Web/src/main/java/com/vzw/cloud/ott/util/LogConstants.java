package com.vzw.cloud.ott.util;

public class LogConstants {
    public static final String USER_LOOKUP_IS_COMPLETE_AND_USER_OBJECT_IS_CREATED_AND_SET_IN_SESSION_SUCCESSFULLY = "NOT AN ERROR - User lookup is complete and user object is created and set in session successfully.";
    public static final String ERROR_CREATING_USER_SESSION = "Error creating user session ";
    public static final String INSIDE_POPULATE_USER_VO_METHOD = "Inside populateUserVO method";
    public static final String LOGGED_IN_USER = "Logged in User: ";
    public static final String LOGGED_IN_USER_GUID = "Logged in User GUID: ";
    public static final String USERS_IP_ADDRESS = "Users IP address - ";
    public static final String EXITING_POPULATE_USER_VO_METHOD = "Exiting populateUserVO method";
    public static final String CAN_NOT_ADD_TOMCAT_RESOURCES = "Can not add tomcat resources";
}
