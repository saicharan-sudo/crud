package com.vzw.cloud.ott.config;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.apache.catalina.Container;
import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatContextCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.sql.DataSource;

/**
 * Spring Boot configuration for Tomcat and data sources.
 *
 * @author Madhusudhanan Krishnan (krisma3)
 */
@Configuration
@EnableConfigurationProperties
@EnableTransactionManagement
@EnableJpaRepositories("com.vzw")
@EntityScan("com.vzw")
public class CloudOTTConfiguration {

    @Value("${spring.cloud-datasource.url}")
    private String connectionURL;

    @Value("${spring.cloud-datasource.jndi-name}")
    private String connectionJndiName;

    @Value("${spring.cloud-datasource.username}")
    private String connectionUserName;

    @Value("${spring.cloud-datasource.password}")
    private String connectionPassword;

    @Value("${spring.cloud-datasource.driverClassName}")
    private String connectionDriverClassName;

    @Value("${spring.audit-datasource.url}")
    private String auditConnectionURL;

    @Value("${spring.audit-datasource.jndi-name}")
    private String auditConnectionJndiName;

    @Value("${spring.audit-datasource.username}")
    private String auditConnectionUserName;

    @Value("${spring.audit-datasource.password}")
    private String auditConnectionPassword;

    @Value("${spring.ott-audit-datasource.url}")
    private String ottAuditConnectionURL;

    @Value("${spring.ott-audit-datasource.jndi-name}")
    private String ottAuditConnectionJndiName;

    @Value("${spring.ott-audit-datasource.username}")
    private String ottAuditConnectionUserName;

    @Value("${spring.ott-audit-datasource.password}")
    private String ottAuditConnectionPassword;

    @Value("${spring.ott-audit-datasource.driverClassName}")
    private String ottAuditConnectionDriverClassName;

    @Value("${spring.audit-datasource.driverClassName}")
    private String auditConnectionDriverClassName;

    @Autowired
    private TomcatCPProperties cpProperties;

   @Bean
    public TomcatEmbeddedServletContainerFactory tomcatFactory() {
        return new TomcatEmbeddedServletContainerFactory() {
            @Override
            protected TomcatEmbeddedServletContainer getTomcatEmbeddedServletContainer(
                    Tomcat tomcat) {
                tomcat.enableNaming();
                TomcatEmbeddedServletContainer container = super.getTomcatEmbeddedServletContainer(tomcat);
                for ( Container child : container.getTomcat().getHost().findChildren() ) {
                    if ( child instanceof Context ) {
                        ClassLoader contextClassLoader = ((Context) child).getLoader().getClassLoader();
                        Thread.currentThread().setContextClassLoader(contextClassLoader);
                        break;
                    }
                }
                return container;
            }

            @Override
            protected void postProcessContext(Context context) {
                createContextResource(context, connectionJndiName, connectionDriverClassName, connectionURL, connectionUserName, connectionPassword);
                createContextResourceLink(context, connectionJndiName);
            }
        };
    }

    @Bean
    @ConditionalOnProperty(name = "tomcat.staticResourceCustomizer.enabled", matchIfMissing = true)
    public EmbeddedServletContainerCustomizer staticResourceCustomizer() {
        return new EmbeddedServletContainerCustomizer() {
            @Override
            public void customize(ConfigurableEmbeddedServletContainer container) {
                if ( container instanceof TomcatEmbeddedServletContainerFactory ) {
                    ((TomcatEmbeddedServletContainerFactory) container)
                    .addContextCustomizers(new TomcatContextCustomizer() {
                        @Override
                        public void customize(Context context) {
                            context.addLifecycleListener(new StaticResourceConfigurer(context));
                        }
                    });
                }
            }

        };
    }

    @Bean(destroyMethod = "", name = "cloudDataSource")
    @Primary
    public DataSource cloudDataSource() throws NamingException {
        JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
        bean.setJndiName("java:comp/env/" + connectionJndiName);
        bean.setProxyInterface(DataSource.class);
        bean.setLookupOnStartup(false);
        bean.afterPropertiesSet();
        return (DataSource) bean.getObject();
    }

    @Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
        jaxb2Marshaller.setPackagesToScan("com.vzw");
        return jaxb2Marshaller;
    }

    @Bean
    public ServletContextInitializer servletContextInitializer() {
        return new ServletContextInitializer() {

            @Override
            public void onStartup(ServletContext servletContext) throws ServletException {
                servletContext.getSessionCookieConfig().setSecure(true);
                servletContext.getSessionCookieConfig().setPath("/");
                servletContext.getSessionCookieConfig().setName("JSESSIONID");
            }
        };

    }

    private void createContextResourceLink(Context context, String cloudJndiName) {
        ContextResourceLink contextResourceLink = new ContextResourceLink();
        contextResourceLink.setGlobal(cloudJndiName);
        contextResourceLink.setName(cloudJndiName);
        contextResourceLink.setType("javax.sql.DataSource");
        context.getNamingResources().addResourceLink(contextResourceLink);
    }

    private void createContextResource(Context context, String connectionJndiName, String connectionDriverClassName, String connectionURL, String connectionUserName, String connectionPassword) {
        ContextResource resource = new ContextResource();
        resource.setName(connectionJndiName);
        resource.setType(DataSource.class.getName());
        resource.setProperty("driverClassName", connectionDriverClassName);
        resource.setProperty("url", connectionURL);
        resource.setProperty("username", connectionUserName);
        resource.setProperty("password", connectionPassword);
        for (String key : cpProperties.getTomcat().keySet()) {
            resource.setProperty(key, cpProperties.getTomcat().get(key));
        }
        resource.setScope("Sharable");
        context.getNamingResources().addResource(resource);
    }


	@Bean(name = "encryptorBean")
    public StringEncryptor stringEncryptor() {
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig config = new SimpleStringPBEConfig();
        config.setPassword("password");
        config.setAlgorithm("PBEWithMD5AndDES");
        config.setKeyObtentionIterations("1000");
        config.setPoolSize("1");
        config.setProviderName("SunJCE");
        config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
        config.setStringOutputType("base64");
        encryptor.setConfig(config);
        return encryptor;
    }
    
}
