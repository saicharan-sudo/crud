/**
 * 
 */
package com.vzw.cloud.ott.controller;

import com.vzw.audit.service.CloudOttQueueService;
import com.vzw.cloud.common.ott.scm.SCMRequestBuilder;
import com.vzw.cloud.common.ott.scm.json.pojo.RespGetViewImpl;
import com.vzw.cloud.common.ott.scm.json.pojo.ResponseCheckoutPage;
import com.vzw.cloud.common.ott.scm.json.pojo.ResponseSubmitPurchaseImpl;
import com.vzw.cloud.common.ott.scm.xml.pojo.ReqGetSubscriberProfile;
import com.vzw.cloud.common.ott.scm.xml.pojo.RespGetSubscriberProfile;
import com.vzw.cloud.common.ott.scm.xml.pojo.RespViewPurchases;
import com.vzw.cloud.common.vo.CloudOTTRequest;
import com.vzw.cloud.common.vo.ott.obi.CloudOBIResponse;
import com.vzw.cloud.common.vo.user.UserVO;
import com.vzw.cloudutils.exception.CloudException;
import com.vzw.ott.app.service.PaymentServiceImpl;
import com.vzw.ott.app.service.SCMService;
import com.vzw.ott.app.service.mail.EmailService;
import com.vzw.ott.app.service.mail.InitialSetupNotification;
import com.vzw.ott.service.CloudOttScmUserInfoService;
import com.vzw.ott.service.CloudOttUserService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import javax.xml.bind.JAXBException;


/**
 * @author annapsa
 *
 */

@RestController
public class SCMController {
	private static Logger logger = LogManager.getLogger(SCMController.class);
	private static final String SUCESS_CODE = "200";

	@Autowired
	private SCMService scmService;

	@Autowired
	private PaymentServiceImpl paymentService;

	@Autowired
	private HttpSession httpSession;

	@Autowired
	private CloudOttUserService cloudOttUserService;

	@Autowired
	private EmailService emailService;

	@Autowired
	private CloudOttScmUserInfoService cloudOttScmUserInfoService;

	private InitialSetupNotification initialSetupNotification;

    @Autowired
    private CloudOttQueueService cloudOttQueueService;

	/**
	 * Rest API to get Storage plans from SCM
	 *
	 * @return RespGetViewImpl
	 * @throws JAXBException
	 * @throws JSONException
	 * @throws CloudException
	 */
	@RequestMapping(value = "/getView", method = { RequestMethod.POST })
	public RespGetViewImpl getView() throws CloudException, JSONException, JAXBException {

		logger.debug("Entering method - GetViewController()");
		return scmService.getView();

	}

	/**
	 * Rest API to get User Profile from SCM
	 *
	 * @return RespGetSubscriberProfile
	 * @throws JAXBException
	 */
	@RequestMapping(value = "/subscriberprofile", method = { RequestMethod.POST })
	public RespGetSubscriberProfile getSubscriberProfile() throws JAXBException {

		logger.debug("Entering method - getSubsriberProfile()");
		ReqGetSubscriberProfile request = SCMRequestBuilder.buildReqGetSubscriberProfile();
		RespGetSubscriberProfile response = scmService.getSubscriberProfile(request);
		return response;

	}

	/**
	 * Rest API to get Purchase History of User from SCM
	 *
	 * @return RespViewPurchases
	 * @throws JAXBException
	 */
	@RequestMapping(value = "/viewpurchases", method = { RequestMethod.POST })
	public RespViewPurchases viewPurchases() throws Exception {

		logger.debug("Entering method - viewPurchases()");
		UserVO userVO = (UserVO) httpSession.getAttribute("userVO");
		return scmService.viewPurchases(userVO.getAmGuid());
	}

	/**
	 * Rest API to get 6-char alphanumeric AccessCode from SCM
	 *
	 * @return ResponseSubmitPurchaseImpl
	 * @throws Exception
	 */
    @RequestMapping(value = "/submitpurchase", method = { RequestMethod.POST })
    public ResponseSubmitPurchaseImpl submitPurchase() throws Exception {

        logger.debug("Entering method - submitPurchases()");
        final boolean isOTT = true;
        return scmService.submitPurchase(isOTT);
    }

	/**
	 * Rest API to get Tax details for CC from SCM
	 *
	 * @return ResponseCheckoutPage
	 * @throws Exception
	 */
	@RequestMapping(value = "/checkoutcart", method = { RequestMethod.POST })
	public ResponseCheckoutPage checkoutCart() throws Exception {

		logger.debug("Entering method - checkoutCart()");
		final String isOTT = "true";
		return scmService.checkoutCart(isOTT);
	}

	@RequestMapping(value = "/planSelection", method =  RequestMethod.POST )
	public CloudOBIResponse userPlanSelection(@RequestBody CloudOTTRequest request){
		return scmService.userPlanSelection(request);
	}
}
