package com.vzw.cloud.ott.config;

import com.rabbitmq.jms.admin.RMQConnectionFactory;
import com.rabbitmq.jms.admin.RMQDestination;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * To create ConnectionFactory for Rabbit MQ from application properties.
 *
 * @author Madhusudhanan Krishnan (krisma3)
 */
@Configuration
@EnableConfigurationProperties
public class JMSConfiguration {

    @Value("${spring.rabbitmq.username}")
    private String userName;

    @Value("${spring.rabbitmq.password}")
    private String password;

    @Value("${spring.rabbitmq.host}")
    private String host;

    @Value("${spring.rabbitmq.virtualHost}")
    private String virtualHost;

    @Value("${spring.rabbitmq.port}")
    private int port;

    @Value("${spring.rabbitmq.queue}")
    private String queue;

    @Value("${spring.rabbitmq.exchange}")
    private String exchange;

    @Value("${spring.rabbitmq.routingKey}")
    private String routingKey;

    @Value("${spring.rabbitmq.ottQueue}")
    private String ottQueue;

    @Value("${spring.rabbitmq.ottRoutingKey}")
    private String ottRoutingKey;

    @Bean
    public RMQConnectionFactory rmqConnectionFactory() {
        RMQConnectionFactory connectionFactory = new RMQConnectionFactory();
        connectionFactory.setUsername(userName);
        connectionFactory.setPassword(password);
        connectionFactory.setVirtualHost(virtualHost);
        connectionFactory.setHost(host);
        connectionFactory.setPort(port);
        return connectionFactory;
    }

    @Bean(name = "CloudJMSDestination")
    public RMQDestination rmqDestination() {
        RMQDestination rmQueue = new RMQDestination();
        rmQueue.setDestinationName(queue);
        rmQueue.setAmqp(true);
        rmQueue.setAmqpQueueName(queue);
        rmQueue.setAmqpExchangeName(exchange);
        rmQueue.setAmqpRoutingKey(routingKey);
        return rmQueue;
    }

    @Bean(name = "OttJMSDestination")
    public RMQDestination rmqOttDestination() {
        RMQDestination rmQueue = new RMQDestination();
        rmQueue.setDestinationName(ottQueue);
        rmQueue.setAmqp(true);
        rmQueue.setAmqpQueueName(ottQueue);
        rmQueue.setAmqpExchangeName(exchange);
        rmQueue.setAmqpRoutingKey(ottRoutingKey);
        return rmQueue;
    }

}
