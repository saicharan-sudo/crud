package com.vzw.cloud.ott.util;

public class OttConstants {
    public static final String VZ_CLOUD_OTT_GET_PROP = "/vzCloudOTT/getProp";
    public static final String VZ_CLOUD_OTT_KA_IS_ALIVE_HTML = "/vzCloudOTT/ka/isAlive.html";
    public static final String USER_VO = "userVO";
    public static final String HTTPS = "https://";
    public static final String VZ_CLOUD_HOME_CLOUD_OVERVIEW_ACTION = "/vzCloud/home/cloudOverview.action";
    public static final String WIRELESS_MARKETING_PAGE = "https://myaccount.verizonwireless.com";
    public static final String OTT = "OTT";
    public static final String ACTIVE = "Active";
    public static final String BOOT_INF_CLASSES = "/BOOT-INF/classes/";
    public static final String META_INF = "META-INF";
    public static final String RESOURCES = "resources";
    public static final String BOOT_INF_CLASSES_1 = "/BOOT-INF/classes!/";
    public static final String META_INF_RESOURCES = "/META-INF/resources";
    public static final String ENABLE_REGISTRATION = "ENABLE_REGISTRATION";
}
