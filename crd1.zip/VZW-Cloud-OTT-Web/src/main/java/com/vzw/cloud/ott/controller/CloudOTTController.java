package com.vzw.cloud.ott.controller;

import com.vzw.cloud.common.vo.CloudOTTResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * Abstract controller for Cloud OTT.
 *
 *@author Madhusudhanan Krishnan(krisma3)
 */
public abstract class CloudOTTController {

    private static Logger logger = LogManager.getLogger(CloudOTTController.class);

    protected CloudOTTResponse cloudOTTResponse = new CloudOTTResponse();

    @ExceptionHandler(Exception.class)
    public CloudOTTResponse handleException(Exception ex, Errors errors) {
        CloudOTTResponse errorResponse = new CloudOTTResponse();
        logger.error("Request:  raised " + ex);
        return errorResponse;
    }
}
