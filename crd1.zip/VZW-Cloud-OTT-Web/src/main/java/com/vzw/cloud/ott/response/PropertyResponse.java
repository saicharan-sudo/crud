package com.vzw.cloud.ott.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * PropertyResponse is used for storing Map of properties.
 *
 * @author Madhusudhanan Krishnan(Madhu)
 */
@Component
@Scope("request")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PropertyResponse {

    @JsonProperty("properties")
    private Map<String, String>  properties;

    public Map<String, String> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, String> properties) {
        this.properties = properties;
    }
}
