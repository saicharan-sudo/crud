package com.vzw.cloud.ott.controller;

import com.vzw.cloud.ott.response.PropertyResponse;
import com.vzw.cloud.ott.util.OttConstants;
import com.vzw.cloudutils.props.CloudProps;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

/**
 * Controller to provide properties required for UI.
 *
 * @author Madhusudhanan Krishnan(krisma3)
 */
@RestController
public class UtilityController {

	private static Logger logger = LogManager.getLogger(UtilityController.class);

	private static String[] ALLOWED_PROPS = { "AM_LOGIN_DOMAIN", "CLOUD_OTT_STATIC_URL", "APP_STORE", "PLAY_STORE",
			"OBI_URL", OttConstants.ENABLE_REGISTRATION, "AM_LOGIN_URL", "AM_LOGOUT_URL" };

	@RequestMapping(value = "/getProp", method = RequestMethod.GET)
	public PropertyResponse getProperty() {
		HashMap<String, String> props = new HashMap<>();
		for (String prop : ALLOWED_PROPS) {
			if (prop.equalsIgnoreCase(OttConstants.ENABLE_REGISTRATION)) {
				props.put(prop, CloudProps.getProperty(prop, "N"));
			} else {
				props.put(prop, CloudProps.getProperty(prop));
			}
		}
		PropertyResponse response = new PropertyResponse();
		response.setProperties(props);
		return response;
	}
}
