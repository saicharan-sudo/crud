package com.vzw.cloud.ott.controller;

import com.vzw.cloud.common.vo.sncr.CloudOTTUserResponse;
import com.vzw.cloudutils.props.CloudProps;
import com.vzw.ott.service.CloudOttUserService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


/**
 * Controller to manager setup and maintenance for OTT user accounts in Synchronoss.
 *
 * @author Madhusudhanan Krishnan (krisma3)
 */
@RestController
public class OTTUserController extends CloudOTTController {

    private static Logger logger = LogManager.getLogger(OTTUserController.class);

    @Autowired
    private CloudOttUserService cloudOttUserService;

    @Autowired
    private HttpSession httpSession;

    /**
     * Rest API to fetch the account summary of the logged in user.
     *
     * @return CloudOTTUserResponse
     */
    @RequestMapping(value = "/userlookup", method = RequestMethod.GET)
    public CloudOTTUserResponse userLookup(HttpServletRequest request) {
        return (CloudOTTUserResponse) httpSession.getAttribute("UserSummary");
    }

    /**
     * Method to validate logged user used for redirection from AM.
     *
     * @return
     */
    @RequestMapping(method = {RequestMethod.GET}, value = "/validateuser")
    public void getGUID(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String redirectUrl = CloudProps.getProperty("CLOUD_OTT_STATIC_URL", "");
        logger.info("Valid User. Redirecting to homepage." + redirectUrl);
        logger.error("Valid user, Redirect OTT URL :" + redirectUrl);
        response.sendRedirect(redirectUrl);
    }
}
