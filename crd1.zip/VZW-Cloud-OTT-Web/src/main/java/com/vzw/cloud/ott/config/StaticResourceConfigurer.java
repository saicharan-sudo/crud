package com.vzw.cloud.ott.config;

import com.vzw.cloud.ott.util.LogConstants;
import com.vzw.cloud.ott.util.OttConstants;
import org.apache.catalina.Context;
import org.apache.catalina.Lifecycle;
import org.apache.catalina.LifecycleEvent;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.WebResourceRoot.ResourceSetType;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * StaticResourceConfigurer configures the static resources for Tomcat embedded with Spring Boot.
 *
 * @author Madhusudhanan Krishnan(krisma3)
 */
public class StaticResourceConfigurer implements LifecycleListener {

    private final Context context;

    StaticResourceConfigurer(Context context) {
        this.context = context;
    }

    @Override
    public void lifecycleEvent(LifecycleEvent event) {
        if ( event.getType().equals(Lifecycle.CONFIGURE_START_EVENT) ) {
            URL location = this.getClass().getProtectionDomain().getCodeSource().getLocation();

            if ( ResourceUtils.isFileURL(location) ) {
                String rootFile = location.getFile();
                if ( rootFile.endsWith(OttConstants.BOOT_INF_CLASSES) ) {
                    rootFile = rootFile.substring(0, rootFile.length() - OttConstants.BOOT_INF_CLASSES.length() + 1);
                }
                if ( !new File(rootFile, OttConstants.META_INF + File.separator + OttConstants.RESOURCES).isDirectory() ) {
                    return;
                }
                try {
                    location = new File(rootFile).toURI().toURL();
                } catch ( MalformedURLException e ) {
                    throw new IllegalStateException(LogConstants.CAN_NOT_ADD_TOMCAT_RESOURCES, e);
                }
            }

            String locationStr = location.toString();
            if ( locationStr.endsWith(OttConstants.BOOT_INF_CLASSES_1) ) {
                locationStr = locationStr.substring(0, locationStr.length() - OttConstants.BOOT_INF_CLASSES_1.length() + 1);
                try {
                    location = new URL(locationStr);
                } catch ( MalformedURLException e ) {
                    throw new IllegalStateException(LogConstants.CAN_NOT_ADD_TOMCAT_RESOURCES, e);
                }
            }
            this.context.getResources().createWebResourceSet(ResourceSetType.RESOURCE_JAR, "/", location,
                    OttConstants.META_INF_RESOURCES);
        }
    }
}