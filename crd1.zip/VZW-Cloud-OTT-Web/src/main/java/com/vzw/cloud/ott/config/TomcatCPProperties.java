package com.vzw.cloud.ott.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * TomcatCPProperties is used for storing Tomcat Configuration properties from application.yml.
 *
 * @author Madhusudhanan Krishnan(krisma3)
 */
@ConfigurationProperties(prefix = "spring.datasource")
@Component
public class TomcatCPProperties {
    private Map<String, String> tomcat = new HashMap<>();

    public Map<String, String> getTomcat() {
        return tomcat;
    }

    public void setTomcat(Map<String, String> tomcat) {
        this.tomcat = tomcat;
    }
}
