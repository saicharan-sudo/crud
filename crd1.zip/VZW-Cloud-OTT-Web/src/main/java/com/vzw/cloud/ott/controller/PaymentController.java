package com.vzw.cloud.ott.controller;

import com.vzw.cloud.common.vo.CloudOTTRequest;
import com.vzw.cloud.common.vo.ott.Errors;
import com.vzw.cloud.common.vo.ott.OBIResponse;
import com.vzw.cloud.common.vo.ott.obi.CloudOBIResponse;
import com.vzw.cloud.common.vo.user.UserVO;
import com.vzw.cloudutils.exception.CloudException;
import com.vzw.ott.app.annotations.AuthenticateUser;
import com.vzw.ott.app.service.PaymentServiceImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;

@RestController
public class PaymentController extends CloudOTTController {

	private static Logger logger = LogManager.getLogger(PaymentController.class);

	@Autowired
	private PaymentServiceImpl paymentService;

	@Autowired
	private HttpSession httpSession;

	@RequestMapping(value = "createInstrument", method = { RequestMethod.POST }, consumes = "application/json")
	@AuthenticateUser
	public CloudOBIResponse createInstrument(@RequestBody CloudOTTRequest request, Errors errors) throws CloudException, MessagingException {

		logger.debug("Inside payment controller ");
		UserVO userVo = (UserVO) httpSession.getAttribute("userVO");
		final String sendEmailFlag = "FALSE";
		CloudOBIResponse response = (CloudOBIResponse) paymentService.createInstrument(request, sendEmailFlag,userVo);
		return response;
	}

	@RequestMapping(value = "listInstruments", method = { RequestMethod.POST })
	@AuthenticateUser
	public OBIResponse listInstrument() throws Exception {

		logger.debug("Inside listInstruments Controller");
		return paymentService.listInstrument();
	}
}
