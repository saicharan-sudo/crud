package com.vzw.cloud.ott;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Spring Boot Application class for Cloud OTT.
 *
 * @author Madhusudhanan Krishnan (krisma3)
 */
@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan({"com.vzw","com.verizon"})
public class CloudOTTApplication {
    public static void main(String[] args) {
        SpringApplication.run(CloudOTTApplication.class, args);
    }
}
