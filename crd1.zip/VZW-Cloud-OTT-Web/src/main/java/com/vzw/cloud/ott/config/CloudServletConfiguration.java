package com.vzw.cloud.ott.config;

import com.vzw.audit.service.CloudOttQueueService;
import com.vzw.cloud.ott.security.filter.LoggingFilter;
import com.vzw.cloud.ott.security.filter.UserLookUpFilter;
import com.vzw.ott.service.CloudOttUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Spring Boot configuration class for configuring security and application filters.
 *
 * @author Madhusudhanan Krishnan (krisma3)
 */
@Configuration
public class CloudServletConfiguration extends SpringBootServletInitializer {

    public static final String PREVOTY_REPORTING_FILTER = "PrevotyReportingFilter";
    public static final String PREVOTY_CONTENT_FILTER = "PrevotyContentFilter";
    public static final String PREVOTY_CSRF_FILTER = "PrevotyCSRFFilter";
    public static final String USER_LOOK_UP_FILTER = "userLookUpFilter";
    private static final String LOGGING_FILTER = "LoggingFilter";

    @Autowired
    private CloudOttUserService cloudOttUserService;

    @Autowired
    private CloudOttQueueService cloudOttQueueService;

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(CloudServletConfiguration.class);
    }

    @Bean
    public FilterRegistrationBean prevotyReportingFilterRegistration() {
        FilterRegistrationBean reg = new FilterRegistrationBean();
        reg.setFilter(new com.prevoty.reporting.Filter());
        reg.setOrder(1);
        reg.setName(PREVOTY_REPORTING_FILTER);
        reg.addUrlPatterns("/*");
        return reg;
    }

    @Bean
    public FilterRegistrationBean prevotyContentFilterRegistration() {
        FilterRegistrationBean reg = new FilterRegistrationBean();
        reg.setFilter(new com.prevoty.content.Filter());
        reg.setOrder(2);
        reg.setName(PREVOTY_CONTENT_FILTER);
        reg.addUrlPatterns("/*");
        return reg;
    }

    @Bean
    public FilterRegistrationBean prevotyCSRFFilterRegistration() {
        FilterRegistrationBean reg = new FilterRegistrationBean();
        reg.setFilter(new com.prevoty.csrf.Filter());
        reg.setOrder(3);
        reg.setName(PREVOTY_CSRF_FILTER);
        reg.addUrlPatterns("/*");
        return reg;
    }

    @Bean
    public FilterRegistrationBean securityFilterRegistrationBean() {
        Collection<String> urlPatterns = new ArrayList<>();
        urlPatterns.add("/*");
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        LoggingFilter loggingFilter = new LoggingFilter();
        registrationBean.setFilter(loggingFilter);
        registrationBean.setName(LOGGING_FILTER);
        registrationBean.setOrder(4);
        registrationBean.setUrlPatterns(urlPatterns);
        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean userLookUpFilterRegistrationBean() {
        Collection<String> urlPatterns = new ArrayList<>();
        urlPatterns.add("/*");
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        UserLookUpFilter userLookUpFilter = new UserLookUpFilter();
        userLookUpFilter.setCloudOttUserService(cloudOttUserService);
        userLookUpFilter.setCloudOttQueueService(cloudOttQueueService);
        registrationBean.setFilter(userLookUpFilter);
        registrationBean.setName(USER_LOOK_UP_FILTER);
        registrationBean.setOrder(5);
        registrationBean.setUrlPatterns(urlPatterns);
        return registrationBean;
    }
}
