package com.vzw.cloud.ott.controller;

import com.vzw.cloud.common.vo.CloudOTTRequest;
import com.vzw.cloud.common.vo.CloudOTTResponse;
import com.vzw.cloud.common.vo.featureUpgrade.CheckoutPlanResponse;
import com.vzw.cloud.common.vo.featureUpgrade.FeatureUpgradeResponse;
import com.vzw.cloudutils.exception.CloudException;
import com.vzw.ott.app.service.StoragePlanServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StoragePlanController {

    @Autowired
    private StoragePlanServiceImpl storagePlanService;

    @RequestMapping(method = {RequestMethod.GET}, value = "/storagePlans/available")
    public FeatureUpgradeResponse retrieveStoragePlans(@RequestParam(value = "isDummy", defaultValue = "false") String isDummy) throws CloudException {
        return storagePlanService.getAvailablePlans(isDummy);
    }

    @RequestMapping(method = {RequestMethod.POST}, value = "/storagePlans/upgrade")
    public FeatureUpgradeResponse upgradeStoragePlan(@RequestBody CloudOTTRequest request) throws CloudException {
        return storagePlanService.upgradeStoragePlan(request);
    }

    @RequestMapping(method = {RequestMethod.POST}, value = "/storagePlans/downgrade")
    public FeatureUpgradeResponse downgradeStoragePlan(@RequestBody CloudOTTRequest request) throws CloudException {
        return storagePlanService.downgradeStoragePlan(request);
    }

    @RequestMapping(method = {RequestMethod.POST}, value = "/storagePlans/checkout")
    public CheckoutPlanResponse checkoutStoragePlan(@RequestParam(value = "isDummy", defaultValue = "false") String isDummy) throws CloudException {
        return storagePlanService.checkoutStoragePlan(isDummy);
    }

    @RequestMapping(method = {RequestMethod.POST}, value = "/storagePlans/confirmCheckout")
    public CloudOTTResponse confirmCheckout(@RequestBody CloudOTTRequest request) throws CloudException {
        return storagePlanService.confirmCheckout(request);
    }

}