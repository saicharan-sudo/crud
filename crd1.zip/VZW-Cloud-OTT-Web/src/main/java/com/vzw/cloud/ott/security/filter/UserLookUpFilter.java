package com.vzw.cloud.ott.security.filter;

import com.vzw.audit.service.CloudOttQueueService;
import com.vzw.cloud.common.ValidationUtils;
import com.vzw.cloud.common.constants.CloudConstants;
import com.vzw.cloud.common.ott.exception.CoreErrorCodes;
import com.vzw.cloud.common.vo.audit.OttAuditVO;
import com.vzw.cloud.common.vo.audit.TransactionName;
import com.vzw.cloud.common.vo.sncr.CloudOTTUserResponse;
import com.vzw.cloud.common.vo.user.AmVO;
import com.vzw.cloud.common.vo.user.UserVO;
import com.vzw.cloud.ott.util.AMConstants;
import com.vzw.cloud.ott.util.LogConstants;
import com.vzw.cloud.ott.util.OttConstants;
import com.vzw.cloudutils.CloudErrorConstants;
import com.vzw.cloudutils.CloudSystemProperty;
import com.vzw.cloudutils.StringUtils;
import com.vzw.cloudutils.exception.CloudException;
import com.vzw.ott.service.CloudOttUserService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 *  UserLookUpFilter to fetch AM Header, validate and filter users.
 *
 *  @author Madhusudhanan Krishnan (Madhu)
 * */
@Component
public class UserLookUpFilter implements Filter {
    private Logger logger = LogManager.getLogger(UserLookUpFilter.class);
    private CloudOttUserService cloudOttUserService;
    private CloudOttQueueService cloudOttQueueService;

    @Override
    public void destroy() {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession();
        
        logger.error("OTT Apr release");
        logger.debug("OTT Apr release");
        
        boolean activeUser = false;
        boolean cloudUser = false;

        String url = ((HttpServletRequest) request).getRequestURI();
        logger.error("OTT_URL - ",url);
        if ( url.equalsIgnoreCase(OttConstants.VZ_CLOUD_OTT_GET_PROP) || url.equalsIgnoreCase(OttConstants.VZ_CLOUD_OTT_KA_IS_ALIVE_HTML) ) {
            chain.doFilter(request, response);
        } else {
            String am_uuid = httpRequest.getHeader(AMConstants.AM_UUID);
            String am_lob = httpRequest.getHeader(AMConstants.AM_LOB);
            logger.error("OTT_URL with am_uuid : " +am_uuid +" , and am_lob"+am_lob);
            try {
                if ( am_lob == null || !am_lob.equalsIgnoreCase(OttConstants.OTT) ) {
                    cloudUser = true;
                } else {

                    if ( session.getAttribute(OttConstants.USER_VO) == null || !((UserVO) session.getAttribute(OttConstants.USER_VO)).getAmGuid().equalsIgnoreCase(am_uuid) ) {
                        CloudOTTUserResponse userSummary = cloudOttUserService.getUserSummary(am_uuid);
                        if ( userSummary.getErrorInfo().getErrorCode().equals(CoreErrorCodes.SUCCESS) ) {
                            if ( userSummary.getAccountSummary() != null && userSummary.getAccountSummary().getUserStatus().equalsIgnoreCase(OttConstants.ACTIVE) ) {
                                activeUser = true;
                            }
                        }
                        if ( !activeUser ) {
                            UserVO user = createUserObject(httpRequest);
                            if ( userSummary.getAccountSummary() != null && userSummary.getAccountSummary().getMsisdn() != null ) {
                                user.setMdn(userSummary.getAccountSummary().getMsisdn());
                            }
                            if ( user.getEmailId() == null ) {
                                CloudOTTUserResponse amUserEmail = cloudOttUserService.getAMUserEmail(am_uuid, null);
                                if ( amUserEmail.getAmUserEmailResponse() != null ) {
                                    user.setEmailId(amUserEmail.getAmUserEmailResponse().getSecurityProfileEmail());
                                }
                            }
                            session.setAttribute(OttConstants.USER_VO, user);
                            session.setAttribute("UserSummary", userSummary);
                            cloudOttQueueService.sendMessage(new OttAuditVO(user.getAmGuid(), TransactionName.LOGIN, OttAuditVO.Application.OTT, OttAuditVO.Status.SUCCESS, null));
                            logger.error(LogConstants.USER_LOOKUP_IS_COMPLETE_AND_USER_OBJECT_IS_CREATED_AND_SET_IN_SESSION_SUCCESSFULLY);
                        }
                    }
                }
            } catch ( Exception e ) {
                logger.error(LogConstants.ERROR_CREATING_USER_SESSION + e.getMessage());
            }

            if ( activeUser ) {
                String redirectURL = OttConstants.HTTPS + httpRequest.getServerName() + ":6131" + OttConstants.VZ_CLOUD_HOME_CLOUD_OVERVIEW_ACTION;
                logger.error("OTT_URL redirect :"+redirectURL);
                httpResponse.sendRedirect(redirectURL);
            } else if ( cloudUser ) {
            	logger.error("This is a cloud user");
                httpResponse.sendRedirect(OttConstants.WIRELESS_MARKETING_PAGE);
            } else {
            	logger.error("Not an active/cloud user");
                chain.doFilter(request, response);
            }
        }
    }

    @Override
    public void init(FilterConfig arg0) {

    }

    /**
     * This method creates the User Object for VZW flow. All the required attributes are retrived from
     * request headers or parameters (if in Test mode).
     *
     * @param request - HttpServletRequest request
     * @return UserVO
     * @throws CloudException - Throws CloudException
     */

    private UserVO createUserObject(HttpServletRequest request) throws CloudException {
        logger.debug(LogConstants.INSIDE_POPULATE_USER_VO_METHOD);
        HttpSession session = request.getSession(false);
        String am_uuid = request.getHeader(AMConstants.AM_UUID);
        String am_email_address = request.getHeader(AMConstants.AM_EMAIL_ADDRESS);
        String sessionId = session.getId();
        String accountNumber, mdn, role, amLoginId, am_csr_user_name, am_csr_role = null;
        if ( StringUtils.isNotBlank(request.getHeader(AMConstants.AM_ACCOUNT_NUMBER)) ) {
            accountNumber = ValidationUtils.validateAccountNumber(request.getHeader(AMConstants.AM_ACCOUNT_NUMBER));
        } else {
            accountNumber = ValidationUtils.validateAccountNumber(request.getParameter(AMConstants.AM_ACCOUNT_NUMBER));
        }
        if ( StringUtils.isNotBlank(request.getHeader(AMConstants.AM_MOBILE_NUMBER)) ) {
            mdn = ValidationUtils.validateMDN(request.getHeader(AMConstants.AM_MOBILE_NUMBER));
        } else {
            mdn = ValidationUtils.validateMDN(request.getParameter(AMConstants.MDN));
        }

        if ( StringUtils.isNotBlank(request.getHeader(AMConstants.AM_ROLE)) ) {
            role = request.getHeader(AMConstants.AM_ROLE);
        } else {
            role = request.getParameter(AMConstants.AM_ROLE);
        }

        if ( StringUtils.isNotBlank(request.getHeader(AMConstants.AM_LOGIN_ID)) ) {
            amLoginId = request.getHeader(AMConstants.AM_LOGIN_ID);
        } else {
            amLoginId = request.getParameter(AMConstants.AM_LOGIN_ID);
        }
        String prodName = request.getHeader(AMConstants.AM_PROD_NAME);

        if ( StringUtils.isNotBlank(request.getHeader(AMConstants.AM_CSR_USER_NAME)) ) {
            am_csr_user_name = ValidationUtils.validateCsr(request.getHeader(AMConstants.AM_CSR_USER_NAME));
        } else {
            am_csr_user_name = ValidationUtils.validateCsr(request.getParameter(AMConstants.AM_CSR_USER_NAME));
        }
        if ( StringUtils.isNotBlank(request.getHeader(AMConstants.AM_CSR_ROLE)) ) {
            am_csr_user_name = ValidationUtils.validateCsr(request.getHeader(AMConstants.AM_CSR_ROLE));
        } else {
            am_csr_role = ValidationUtils.validateCsr(request.getParameter(AMConstants.AM_CSR_ROLE));
        }
        String am_name = request.getHeader(AMConstants.AM_NAME);

        if ( StringUtils.isEmpty(am_uuid) ) {
            throw new CloudException(CloudErrorConstants.CLOUD_INVALID_INPUT, "AM_UUID doesn't match.");
        }
        if ( am_email_address == null ) {
            CloudOTTUserResponse amUserEmail = cloudOttUserService.getAMUserEmail(am_uuid, null);
            if ( amUserEmail.getAmUserEmailResponse() != null ) {
                am_email_address = amUserEmail.getAmUserEmailResponse().getSecurityProfileEmail();
            }
        }

        String clientIP = null;
        logger.info(LogConstants.LOGGED_IN_USER + amLoginId);
        logger.info(LogConstants.LOGGED_IN_USER_GUID + am_uuid);

        if ( null != request.getHeader(CloudConstants.CLIENT_IP_REQUEST_HEADER) ) {
            clientIP = request.getHeader(CloudConstants.CLIENT_IP_REQUEST_HEADER);
        } else if ( null != request.getHeader(CloudConstants.X_FORWARDED_REQUEST_HEADER) )
            clientIP = request.getHeader(CloudConstants.X_FORWARDED_REQUEST_HEADER);

        if ( null == clientIP || CloudConstants.BLANK.equalsIgnoreCase(clientIP.trim()) ) {
            clientIP = request.getRemoteAddr();
        }

        UserVO userVO = new UserVO("", sessionId, accountNumber, mdn);
        AmVO amVO = new AmVO();
        amVO.setAmr(role);
        userVO.setAmGuid(am_uuid);
        userVO.setAmLoginId(amLoginId);
        userVO.setProdName(prodName);
        userVO.setDeviceName(prodName);
        userVO.setCloneId(CloudSystemProperty.SERVER_ID);
        userVO.setIpAddress(clientIP);
        userVO.setEmailId(am_email_address);
        logger.error(LogConstants.USERS_IP_ADDRESS + userVO.getIpAddress());
        userVO.setAmName(am_name);
        userVO.setBusinessType(OttConstants.OTT);
        if ( StringUtils.isNotBlank(am_csr_user_name) ) {
            userVO.setCsr(true);
            userVO.setCsrUserName(am_csr_user_name);
            amVO.setCsr(am_csr_role);
        }
        userVO.setUserAmInfo(amVO);
        userVO.setActiveFlow(true);

        ValidationUtils.validateIPAccess(userVO);
        logger.debug(LogConstants.EXITING_POPULATE_USER_VO_METHOD);

        return userVO;
    }

    public void setCloudOttUserService(CloudOttUserService cloudOttUserService) {
        this.cloudOttUserService = cloudOttUserService;
    }

    public void setCloudOttQueueService(CloudOttQueueService cloudOttQueueService) {
        this.cloudOttQueueService = cloudOttQueueService;
    }
}
